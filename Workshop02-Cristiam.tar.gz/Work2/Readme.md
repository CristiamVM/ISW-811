#Workshop 02


## ¿Que necesitamos para desplegar una aplicacion web?


- Servidor
- Dominio
- Una IP
- Almacenamiento
- Una App (backend, frontend, fullstack)
- Una base de datos
- Presupuesto
- Seguridad
    - Firewall
-SEO
    -Analiticas

## Implementacion de servidor LAMP

### Para cambiar el hostname se utiliza el siguiente comando(en este caso se cambia especificamente a "webserver")

Cambiamos el nombre por defecto que traia la maquina para que tubiera mas congruencia

```
sudo hostnamectl set-hostname webserver

```

### Se actualizo el hostname en el archivo hosts
Actulizamos el nombre del domino de la maquina para que no alla problemas con el nombre de la maquina

```
sudo nano /etc/hosts

```

### Actualizacion de lista de paquetes elegibles
Hay que actualizar la base de datos de paquetes disponibles

```
sudo apt-get update

```


### Instalar paquetes
Se intalan apache 2 mariandb-server, mariandb-client,php
```
sudo apt-get install vim vim-nox \
        curl git apache2 mariadb-server mariadb-client \
        php7.4 php7.4-bcmath php7.4-curl php7.4-json \
        php7.4-mbstring php7.4-mysql php7.4-xml
```


### Comprobar la IP del server
Utilizamos la terminal bash ir a la carpeta de la maquina virtual, abrimo el vagrantFile para verificar la ip y la testeamos con un ping
![Terminal Bash]( ./Images/comprobacion%20de%20ip.png "Comprobacion de ip asignada")


### Configuracion de la ip y el dominio
usamos la terminal bash para ir a la carpeta de host en system32
![Terminal Bash]( ./Images/ip%20y%20dominio.png "Comprobacion de ip asignada")

#### Una vez adentro de host.txt asignamos el "private_network"

![Terminal Bash]( ./Images/ip%20y%20dominio%202.png "Creacion de la ip y el dominio en el host.txt")


### Comprobamos el estado de apache en el navegador
Abrimos el navegador e introducimos el dominio que le asignamos y deberia cargar la pagina default de apache

![Navegador]( ./Images/comprobacion%20de%20dominio.png "Comprobacion de dominio asignado")


### Habilitar modulos
   habilitamos los modulos para soportar host virtuales y certificados SSl, esto se ejecuta 

```
sudo a2enmod vhost_alias rewrite ssl
sudo systemctl restart apache2

```
![terminal Bash]( ./Images/https%20y%20SSL.png "comandos en la maquina virtual")


### Se crea una pagina html para que la hostee 

Se crean las carpetas por la terminal bash para almacenar el codigo

![terminal Bash]( ./Images/carpetas%20para%20el%20codigo.png "creacion de la carpetas")


#### codigo HTML
  Se crea un codigo HTML simple ra que se muestre en al pagina que estamos levantando

![Visual Studio Code]( ./Images/codigo%20HTML.png "creacion del HTML")


### Montar la carpeta de sitios 
  Sincronizamos el la pagina de prueba que acabamos de crear con la maquina virutal para asi mejorar el flujo de trabajo

![Visual Studio Code]( ./Images/edicion%20del%20vagrantfile.png "comandos en la maquina virtual")


### Reinicio de la maquina virtual
Usamos la terminal de bash para reiniciar la maquina y que se apliquen los cambios

![terminal Bash]( ./Images/cerrar%20Debian.png "Cerramos y levantamos la maquina")


### Creacion el archivo conf para el sitio
  Es necesario crear el archivo .conf de esta manera podemos ubicar los arvhivos

![terminal Bash]( ./Images/creacion%20del%20archivo%20conf.png "Creacion de carpetas")


### Codigo para crear el virtualHost
  Usamos este codigo para crear el virtualHost de la conexion virtual

```
    <VirtualHost *:80>
  ServerAdmin webmaster@mizaq.isw811.xyz
  ServerName mizaq.isw811.xyz

  # Indexes + Directory Root.
  DirectoryIndex index.php index.html
  DocumentRoot /home/vagrant/sites/mizaq.isw811.xyz

  <Directory /home/vagrant/sites/mizaq.isw811.xyz>
    DirectoryIndex index.php index.html
    AllowOverride All
    Require all granted
  </Directory>

  ErrorLog ${APACHE_LOG_DIR}/mizaq.isw811.xyz.error.log
  LogLevel warn
  CustomLog ${APACHE_LOG_DIR}/mizaq.isw811.xyz.access.log combined
    </VirtualHost>
```


### Copiar el conf a sites-available
  Usando el siguente comando vamos a copiar el archivo .conf en los sitios disponibles de Apache 2

```
sudo cp /vagrant/confs/cristiam.isw811.xyz.conf
/etc/apache2/sites-available
```

![terminal Bash]( ./Images/copia%20de%20la%20pagina%20HTML.png "Creacion de carpetas")

### Configuracion de parametro "ServerName"
  Al probar el apache tiraba un error "Could not reliably determine the server's fully qualified domain name", asi que hubo que ejecutar el siguente comando para agregar la directiva de servername a la configuracion de Apache2

```
echo "ServerName webserver" | sudo tee -a
/etc/apache2/apache2.conf
```

![terminal Bash]( ./Images/configuracion%20de%20parametro%20servername.png "Configuracion de parametro Servername")


### Habilitar el nuevo sitio
  Para asegurarse que todo este bien y todo se alla guardado de forma correcta volvemos a habilitar el sitio y reinicar el apache

   ```
  sudo a2ensite mizaq.isw811.xyz.conf
  sudo systemctl restart apache2.service
  ```

### Vefrificacion del nuevo sitio 
  Simplemente en un navegador de nuestra maquina anfitriona buscamos el sitio que acabamos de hostear en la maquina virtual

  ![Chorme]( ./Images/website%20funcionado.png "Sitio de prueba creado en HTML")
